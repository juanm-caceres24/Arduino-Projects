# Generic GD32 HAL based on the MFL Arduino Core

This HAL is eventually intended to act as the generic HAL for all GD32 chips using the MFL library.

Currently it supports:
 * GD32F303RET6

Targeting the official [MFL Arduino Core](https://github.com/bnmguy/ArduinoCore_MFL).
